using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using static GestionStock.Pages.CreateAModel;

namespace GestionStock.Pages
{
    public class CreateModel : PageModel
    {
        public AuteurInfo auteur { get; private set; } = new AuteurInfo();
        public string errorMessage  = "";
        public string SuccessMessage  = "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            auteur.NomAuteur = Request.Form["nom"]!;
            auteur.EmailAuteur = Request.Form["email"]!;
            auteur.telephoneAut = Request.Form["telephone"]!;
            auteur.AdresseAut = Request.Form["adresse"]!;

            if (auteur.NomAuteur.Length == 0 || auteur.EmailAuteur.Length == 0 || auteur.telephoneAut.Length == 0 || auteur.AdresseAut.Length == 0)
            {
                errorMessage = "Tous les champs sont obligatoires";
                return;
            }

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "INSERT INTO Auteur (NomAuteur, EmailAuteur, telephoneAut, AdresseAut) VALUES (@nom, @email, @telephone, @adresse)";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nom", auteur.NomAuteur);
                        cmd.Parameters.AddWithValue("@email", auteur.EmailAuteur);
                        cmd.Parameters.AddWithValue("@telephone", auteur.telephoneAut);
                        cmd.Parameters.AddWithValue("@adresse", auteur.AdresseAut);
                        cmd.ExecuteNonQuery();
                    }
                    SuccessMessage = "Auteur ajout� avec succ�s";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
                errorMessage = "Une erreur s'est produite lors de l'ajout de l'auteur.";
            }

            // Redirect to the appropriate page (adjust the path accordingly)
            RedirectToPage("/CreateA");
        }
    }
}
