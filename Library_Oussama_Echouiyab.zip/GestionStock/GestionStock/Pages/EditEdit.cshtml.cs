using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class EditEditModel : PageModel
    {
        public EditInfo edit = new EditInfo();

        public void OnGet()
        {
            string id = Request.Query["id"]!;
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Editeur WHERE IDEditeur=@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        SqlDataReader rd = cmd.ExecuteReader();
                        if (rd.Read())
                        {
                            edit.IDEditeur = rd.GetInt32(0);
                            edit.NomEditeur = rd.GetString(1);
                            edit.DescripEditeur = rd.GetString(2);
                            edit.EmailEdit = rd.GetString(3);
                            edit.telephoneEdi = rd.GetString(4);
                            edit.AddressEdit = rd.GetString(5);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public IActionResult OnPost()
        {
            edit.IDEditeur = Convert.ToInt32(Request.Form["id"]);
            edit.NomEditeur = Request.Form["nomed"];
            edit.DescripEditeur = Request.Form["descriptioned"];
            edit.EmailEdit = Request.Form["emailed"];
            edit.telephoneEdi = Request.Form["telephoned"];
            edit.AddressEdit = Request.Form["addressed"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "UPDATE Editeur SET NomEditeur = @nomed, DescripEditeur = @descriptioned, EmailEdit = @emailed, telephoneEdi = @telephoned, AddressEdit = @addressed WHERE IDEditeur = @id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nomed", edit.NomEditeur);
                        cmd.Parameters.AddWithValue("@descriptioned", edit.DescripEditeur);
                        cmd.Parameters.AddWithValue("@emailed", edit.EmailEdit);
                        cmd.Parameters.AddWithValue("@telephoned", edit.telephoneEdi);
                        cmd.Parameters.AddWithValue("@addressed", edit.AddressEdit);
                        cmd.Parameters.AddWithValue("@id", edit.IDEditeur);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            return RedirectToPage("/Editeur");
        }
    }
}