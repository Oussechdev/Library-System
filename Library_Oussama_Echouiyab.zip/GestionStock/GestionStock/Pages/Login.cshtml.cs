using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GestionStock.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
            // Handle GET request
        }

        public IActionResult OnPost(string username, string password)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Your custom authentication logic
            var isAuthenticated = AuthenticateUser(username, password);

            if (isAuthenticated)
            {
                // Successful login, redirect to /Clients
                return Redirect("/Clients");

            }
            else
            {
                // Failed login, display an error
                ViewData["ErrorMessage"] = "Invalid login attempt.";
                return Page();
            }
        }

        // Your custom authentication logic goes here
        private bool AuthenticateUser(string username, string password)
        {
            // Logging for debugging
            Console.WriteLine($"Attempting login for {username}");
            return (username == "admin" && password == "123");
        }

    }
}
