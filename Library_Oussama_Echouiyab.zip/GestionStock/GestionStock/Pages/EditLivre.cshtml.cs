using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data;
using System.Data.SqlClient;
using Serilog;
using Microsoft.Extensions.Configuration;
using static GestionStock.Pages.CreateAModel;

namespace GestionStock.Pages
{
    public class EditLivreModel : PageModel
    {
        public LivreInfo livre = new LivreInfo();
        public List<EditInfo> Editeur = new List<EditInfo>();
        public List<AuteurInfo> Auteur = new List<AuteurInfo>();
        public List<CatInfo> Categorie = new List<CatInfo>();
        public string ErrorMessage = "";
        public string SuccessMessage = "";
        string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

        public void OnGet()
        {
            PopulateDropdowns();

            string id = Request.Query["id"];
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Livre WHERE ID=@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        SqlDataReader rd = cmd.ExecuteReader();
                        if (rd.Read())
                        {
                            livre.ID = rd.GetInt32(0);
                            livre.Titre = rd.GetString(1);
                            livre.ISBN = rd.GetString(2);
                            livre.IDEditeur = rd.GetInt32(3);
                            livre.IDAuteur = rd.GetInt32(4);
                            livre.IDCat = rd.GetInt32(5);
                            livre.Description = rd.GetString(6);
                            livre.DateRealisation = rd.GetInt32(7);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
        }

        public void OnPost()
        {
            PopulateDropdowns();

            livre.ID = Convert.ToInt32(Request.Form["id"]);
            livre.Titre = Request.Form["title"];
            livre.ISBN = Request.Form["isbn"];
            if (int.TryParse(Request.Form["idediteur"], out int idediteur))
            {
                livre.IDEditeur = idediteur;
            }
            else
            {
                HandleInvalidValue("ID Editeur");
                return;
            }

            if (int.TryParse(Request.Form["idauteur"], out int idauteur))
            {
                livre.IDAuteur = idauteur;
            }
            else
            {
                HandleInvalidValue("ID Auteur");
                return;
            }

            if (int.TryParse(Request.Form["idcategorie"], out int idcat))
            {
                livre.IDCat = idcat;
            }
            else
            {
                HandleInvalidValue("ID Categorie");
                return;
            }

            livre.Description = Request.Form["description"];

            // Validate and set AnneeEdit value
            if (int.TryParse(Request.Form["anneedit"], out int anneeEdit))
            {
                livre.DateRealisation = anneeEdit;
            }
            else
            {
                HandleInvalidValue("AnneeEdit");
                return;
            }

            if (string.IsNullOrWhiteSpace(livre.Titre) || string.IsNullOrWhiteSpace(livre.ISBN) || string.IsNullOrWhiteSpace(livre.Description))
            {
                ErrorMessage = "Tous les champs sont obligatoires";
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "UPDATE Livre SET Titre=@title, ISBN=@isbn, IDEditeur=@idediteur, IDAuteur=@idauteur, IDCat=@idcategorie, Description=@description, DateRealisation=@anneedit " +
                        "WHERE ID=@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.Add("@id", SqlDbType.Int).Value = livre.ID;
                        cmd.Parameters.Add("@title", SqlDbType.NVarChar).Value = livre.Titre;
                        cmd.Parameters.Add("@isbn", SqlDbType.NVarChar).Value = livre.ISBN;
                        cmd.Parameters.Add("@idediteur", SqlDbType.Int).Value = livre.IDEditeur;
                        cmd.Parameters.Add("@idauteur", SqlDbType.Int).Value = livre.IDAuteur;
                        cmd.Parameters.Add("@idcategorie", SqlDbType.Int).Value = livre.IDCat;
                        cmd.Parameters.Add("@description", SqlDbType.NVarChar).Value = livre.Description;
                        cmd.Parameters.Add("@anneedit", SqlDbType.Int).Value = livre.DateRealisation;
                        cmd.ExecuteNonQuery();
                    }
                    SuccessMessage = "livre edite avec succ�s";
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }

            RedirectToPage("/LivreIndex");
        }

        private void HandleInvalidValue(string fieldName)
        {
            livre.DateRealisation = 0;
            ErrorMessage = $"Invalid value for {fieldName}";
        }

        private void PopulateDropdowns()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Query to get all Editeurs
                string sqlEditeurs = "SELECT IDEditeur, NomEditeur FROM Editeur";
                using (SqlCommand cmd = new SqlCommand(sqlEditeurs, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Editeur.Add(new EditInfo { IDEditeur = reader.GetInt32(0), NomEditeur = reader.GetString(1) });
                    }
                    reader.Close();
                }

                // Query to get all Auteurs
                string sqlAuteurs = "SELECT IDAuteur, NomAuteur FROM Auteur";
                using (SqlCommand cmd = new SqlCommand(sqlAuteurs, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Auteur.Add(new AuteurInfo { IDAuteur = reader.GetInt32(0), NomAuteur = reader.GetString(1) });
                    }
                    reader.Close();
                }

                // Query to get all Categories
                string sqlCategories = "SELECT IDCat, NomCat FROM Categorie";
                using (SqlCommand cmd = new SqlCommand(sqlCategories, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Categorie.Add(new CatInfo { IDCat = reader.GetInt32(0), NomCat = reader.GetString(1) });
                    }
                    reader.Close();
                }
            }
        }
    }
}