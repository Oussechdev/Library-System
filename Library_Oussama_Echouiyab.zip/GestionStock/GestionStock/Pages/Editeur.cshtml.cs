using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class EditeurModel : PageModel
    {
        public List<EditInfo> listEdit { get; } = new List<EditInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                    SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string sql = "SELECT * FROM Editeur";
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    EditInfo editinf = new EditInfo();
                    editinf.IDEditeur = rd.GetInt32(0);
                    editinf.NomEditeur = rd.GetString(1);
                    editinf.DescripEditeur = rd.GetString(2);
                    editinf.EmailEdit = rd.GetString(3);
                    editinf.telephoneEdi = rd.GetString(4);
                    editinf.AddressEdit = rd.GetString(5);
                    listEdit.Add(editinf);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }
    public class EditInfo
    {
        internal string telephoneAut;

        public int IDEditeur { get; set; }
        public string? NomEditeur { get; set; }
        public string? DescripEditeur { get; set; }
        public string? EmailEdit { get; set; }
        public string? telephoneEdi { get; set; }
        public string? AddressEdit { get; set; }
        public int IDAuteur { get; internal set; }
        public string NomAuteur { get; internal set; }
        public string EmailAuteur { get; internal set; }
        public string AddressAut { get; internal set; }
    }
}