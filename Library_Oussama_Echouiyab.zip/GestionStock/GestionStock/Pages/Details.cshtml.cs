using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;


namespace GestionStock.Pages.Books
{
    public class DetailsModel : PageModel
    {
        public BookInfo BookInfo { get; set; } = new BookInfo();

        public void OnGet(int id)
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "SELECT * FROM [Book] WHERE Id=@id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            if (rd.Read())
                            {
                                BookInfo.Id = rd.GetInt32(0);
                                BookInfo.Titre = rd.GetString(1);
                                BookInfo.NomAuteur = rd.GetString(2);
                                BookInfo.DateRealisation = rd.GetInt32(0);
                                BookInfo.Description = rd.GetString(4);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions more gracefully (log or display user-friendly error messages)
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }
}
