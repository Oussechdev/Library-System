﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class Clients : PageModel
    {
        public List<BookInfo> ListBooks { get; } = new List<BookInfo>();

        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Livre";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            while (rd.Read())
                            {
                                BookInfo bookInfo = new BookInfo
                                {
                                    Id = rd.GetInt32(0),
                                    Titre = rd.IsDBNull(1) ? null : rd.GetString(1),
                                    ISBN = rd.GetInt32(2), // Assuming ISBN is in the second column
                                    IDEditeur = rd.GetInt32(3),
                                    IDAuteur = rd.GetInt32(4),
                                    IDCat = rd.GetInt32(5),
                                    Description = rd.IsDBNull(6) ? null : rd.GetString(6),
                                    DateRealisation = rd.GetInt32(7) // Assuming DateRealisation is in the eighth column
                                };

                                ListBooks.Add(bookInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }

    public class BookInfo
    {
        public static object? EmailAuteur { get; internal set; }

        public static object? TelephoneAuteur { get; internal set; }
        public static object? AdresseAut { get; internal set; }
        public int Id { get; set; }
        public string? Titre { get; set; }
        public string? NomAuteur { get; set; } 

        public int ISBN { get; set; }
        public int IDEditeur { get; set; }
        public int IDAuteur { get; set; }
        public int IDCat { get; set; }
        public string? Description { get; set; }
        public int DateRealisation { get; set; }

        public override bool Equals(object? obj)
        {
            return obj is BookInfo info &&
                   Id == info.Id &&
                   Titre == info.Titre &&
                   NomAuteur == info.NomAuteur &&
                   ISBN == info.ISBN &&
                   IDEditeur == info.IDEditeur &&
                   IDAuteur == info.IDAuteur &&
                   IDCat == info.IDCat &&
                   Description == info.Description &&
                   DateRealisation == info.DateRealisation;
        }
    }
}
