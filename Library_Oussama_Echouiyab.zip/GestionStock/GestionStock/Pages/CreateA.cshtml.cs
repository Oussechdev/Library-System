using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class CreateAModel : PageModel
    {
        public List<AuteurInfo> listAuteur { get; } = new List<AuteurInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Auteur";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            AuteurInfo auteurinf = new AuteurInfo();
                            auteurinf.IDAuteur = rd.GetInt32(0);
                            auteurinf.NomAuteur = rd.IsDBNull(1) ? null : rd.GetString(1);
                            auteurinf.EmailAuteur = rd.IsDBNull(2) ? null : rd.GetString(2);
                            auteurinf.telephoneAut = rd.IsDBNull(3) ? null : rd.GetString(3);
                            auteurinf.AdresseAut = rd.IsDBNull(4) ? null : rd.GetString(4);
                            listAuteur.Add(auteurinf);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public class AuteurInfo
        {
            
            public int IDAuteur { get; set; }
            public string? NomAuteur { get; set; }
            public string? EmailAuteur { get; set; }
            public string? telephoneAut{ get; set; }
            public string? AdresseAut { get; set; }
           
        }
    }
}