using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class ClientsModel : PageModel
    {
        public List<BookInfo>? ListBooks { get; set; }
        public bool TitreExists { get; set; }

        public void OnGet(string searchTerm)
        {
            ListBooks = new List<BookInfo>();
            TitreExists = false;

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Book";

                    if (!string.IsNullOrEmpty(searchTerm))
                    {
                        // Use parameterized query to avoid SQL injection
           

                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {
                            // Add parameter for the search term
                            cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                while (rd.Read())
                                {
                                    BookInfo bookInfo = new BookInfo
                                    {
                                        Id = rd.GetInt32(0),
                                        Titre = rd.IsDBNull(1) ? null : rd.GetString(1),
                                        ISBN = rd.GetInt32(0),
                                        IDEditeur = rd.GetInt32(0),
                                        IDAuteur = rd.GetInt32(0),
                                        IDCat = rd.GetInt32(0),
                                        Description = rd.IsDBNull(4) ? null : rd.GetString(4),
                                        DateRealisation = rd.GetInt32(0)
                                    };

                                    ListBooks.Add(bookInfo);
                                }
                            }
                        }

                        // Check if Titre exists
                        TitreExists = ListBooks.Count > 0;
                    }
                    else
                    {
                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {
                            using (SqlDataReader rd = cmd.ExecuteReader())
                            {
                                while (rd.Read())
                                {
                                    BookInfo bookInfo = new BookInfo
                                    {
                                        Id = rd.GetInt32(0),
                                        Titre = rd.IsDBNull(1) ? null : rd.GetString(1),
                                        ISBN = rd.GetInt32(0),
                                        IDEditeur = rd.GetInt32(0),
                                        IDAuteur = rd.GetInt32(0),
                                        IDCat = rd.GetInt32(0),
                                        Description = rd.IsDBNull(4) ? null : rd.GetString(4),
                                        DateRealisation = rd.GetInt32(0)
                                    };

                                    ListBooks.Add(bookInfo);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
                // Handle the exception as needed (logging, displaying an error message, etc.)
            }
        }

        public class BookInfo
        {
            public int Id { get; set; }
            public string? Titre { get; set; }
            public int ISBN { get; set; }
            public int IDEditeur { get; set; }
            public int IDAuteur { get; set; }
            public int IDCat { get; set; }
            public string? Description { get; set; }
            public int DateRealisation { get; set; }
            public string? NomAuteur { get; internal set; }
        }
    }
}
