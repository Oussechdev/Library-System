using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class EditModel : PageModel
    {
        public BookInfo BookInfo = new BookInfo();

        public void OnGet()
        {
            string id = Request.Query["id"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "SELECT * FROM [Livre] WHERE Id=@id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        using (SqlDataReader rd = cmd.ExecuteReader())
                        {
                            if (rd.Read())
                            {
                                BookInfo.Id = rd.GetInt32(0);
                                BookInfo.Titre = rd.GetString(1);
                                BookInfo.NomAuteur = rd.GetString(2);
                                BookInfo.DateRealisation = rd.GetInt32(0);
                                BookInfo.Description = rd.GetString(4);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions more gracefully (log or display user-friendly error messages)
                Console.WriteLine("Exception " + ex.ToString());
            }
        }

        public void OnPost()
        {
            string id = Request.Form["id"];
            string titre = Request.Form["titre"];
            string nomAuteur = Request.Form["nomAuteur"];
            string dateRealisation = Request.Form["dateRealisation"];
            string description = Request.Form["description"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "UPDATE [Livre] SET Titre=@titre, NomAuteur=@nomAuteur, DateRealisation=@dateRealisation, Description=@description WHERE Id=@id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@titre", titre);
                        cmd.Parameters.AddWithValue("@nomAuteur", nomAuteur);
                        cmd.Parameters.AddWithValue("@dateRealisation", dateRealisation);
                        cmd.Parameters.AddWithValue("@description", description);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions more gracefully (log or display user-friendly error messages)
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }
}
