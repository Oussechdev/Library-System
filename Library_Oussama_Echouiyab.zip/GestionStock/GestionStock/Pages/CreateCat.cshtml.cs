using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class CreateCatModel : PageModel
    {
        public CatInfo cat = new CatInfo();
        public string ErrorMessage = "";
        public string SuccessMessage = "";

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            cat.NomCat = Request.Form["nomcat"];
            cat.DescriptionCat = Request.Form["description"];

            if (cat.NomCat.Length == 0 || cat.DescriptionCat.Length == 0)
            {
                ErrorMessage = "Tous les champs sont obligatoires";
                return Page();
            }

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "INSERT INTO Categorie (NomCat, DescriptionCat) VALUES (@nomcat, @description)";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nomcat", cat.NomCat);
                        cmd.Parameters.AddWithValue("@description", cat.DescriptionCat);
                        cmd.ExecuteNonQuery();
                    }
                    SuccessMessage = "Cat�gorie ajout�e avec succ�s";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
                ErrorMessage = "Une erreur s'est produite lors de l'ajout de la cat�gorie.";
                return Page();
            }

            // Redirige vers la page d'index des cat�gories
            return RedirectToPage("/CategorieIndex");
        }
    }
}