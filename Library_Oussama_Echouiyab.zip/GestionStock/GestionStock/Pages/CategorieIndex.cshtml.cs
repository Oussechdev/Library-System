using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class CategorieIndexModel : PageModel
    {
        public List<CatInfo> listCat { get; } = new List<CatInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string sql = "SELECT * FROM Categorie";
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    CatInfo catinf = new CatInfo();
                    catinf.IDCat = rd.GetInt32(0);
                    catinf.NomCat = rd.GetString(1);
                    catinf.DescriptionCat = rd.GetString(2);
                    listCat.Add(catinf);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }
    public class CatInfo
    {
        public int IDCat { get; set; }
        public string? NomCat { get; set; }
        public string? DescriptionCat { get; set; }

    }
}