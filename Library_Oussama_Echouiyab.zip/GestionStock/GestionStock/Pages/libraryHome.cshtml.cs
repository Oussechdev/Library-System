using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GestionStock.Pages
{
    public class libraryHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
