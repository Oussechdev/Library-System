using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class EditCatModel : PageModel
    {
        public CatInfo cat = new CatInfo();

        public void OnGet()
        {
            string id = Request.Query["id"]!;
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Categorie WHERE IDCat=@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        SqlDataReader rd = cmd.ExecuteReader();
                        if (rd.Read())
                        {
                            cat.IDCat = rd.GetInt32(0);
                            cat.NomCat = rd.GetString(1);
                            cat.DescriptionCat = rd.GetString(2);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public IActionResult OnPost()
        {
            cat.IDCat = Convert.ToInt32(Request.Form["id"]);
            cat.NomCat = Request.Form["nomcat"];
            cat.DescriptionCat = Request.Form["description"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "UPDATE Categorie SET NomCat = @nomcat, DescriptionCat = @description WHERE IDCat = @id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nomcat", cat.NomCat);
                        cmd.Parameters.AddWithValue("@description", cat.DescriptionCat);
                        cmd.Parameters.AddWithValue("@id", cat.IDCat);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }


            return RedirectToPage("/CategorieIndex");
        }
    }
}