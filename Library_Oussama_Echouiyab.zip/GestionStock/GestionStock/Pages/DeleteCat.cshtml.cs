using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GestionStock.Pages
{
    public class DeleteCatModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
