using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Data;
using static GestionStock.Pages.CreateAModel;

namespace GestionStock.Pages
{
    public class CreateLivreModel : PageModel
    {
        public LivreInfo livreinfo = new LivreInfo();
        public List<EditInfo> Editeur = new List<EditInfo>();
        public List<AuteurInfo> Auteur = new List<AuteurInfo>();
        public List<CatInfo> Categorie = new List<CatInfo>();

        public string ErrorMessage = "";
        public string SuccessMessage = "";

        public void OnGet()
        {
            PopulateDropdowns();
        }

        public void OnPost()
        {
            PopulateDropdowns(); // Repopulate dropdowns to ensure the lists have the latest data

            livreinfo.Titre = Request.Form["titre"]!;
            livreinfo.ISBN = Request.Form["isbn"]!;

            // Validate and set ID values
            if (int.TryParse(Request.Form["idediteur"], out int idediteur))
            {
                livreinfo.IDEditeur = idediteur;
            }
            else
            {
                HandleInvalidValue("ID Editeur");
                return;
            }

            if (int.TryParse(Request.Form["idauteur"], out int idauteur))
            {
                livreinfo.IDAuteur = idauteur;
            }
            else
            {
                HandleInvalidValue("ID Auteur");
                return;
            }

            if (int.TryParse(Request.Form["idcategorie"], out int idcat))
            {
                livreinfo.IDCat = idcat;
            }
            else
            {
                HandleInvalidValue("ID Categorie");
                return;
            }

            livreinfo.Description = Request.Form["description"]!;

            // Validate and set AnneeEdit value
            if (int.TryParse(Request.Form["anneedit"], out int anneeEdit))
            {
                livreinfo.DateRealisation = anneeEdit;
            }
            else
            {
                HandleInvalidValue("DateRealisation");
                return;
            }

            // Validate other required fields
            if (string.IsNullOrWhiteSpace(livreinfo.Titre) || string.IsNullOrWhiteSpace(livreinfo.ISBN) || string.IsNullOrWhiteSpace(livreinfo.Description))
            {
                ErrorMessage = "Tous les champs sont obligatoires";
                return;
            }

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "INSERT INTO Livre (Titre,ISBN,IDEditeur,IDAuteur,IDCat,Description,DateRealisation) " +
                        "VALUES (@title,@isbn,@idediteur,@idauteur,@idcategorie,@description,@anneedit)";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.Add("@title", SqlDbType.NVarChar).Value = livreinfo.Titre;
                        cmd.Parameters.Add("@isbn", SqlDbType.NVarChar).Value = livreinfo.ISBN;
                        cmd.Parameters.Add("@idediteur", SqlDbType.NVarChar).Value = livreinfo.IDEditeur;
                        cmd.Parameters.Add("@idauteur", SqlDbType.NVarChar).Value = livreinfo.IDAuteur;
                        cmd.Parameters.Add("@idcategorie", SqlDbType.NVarChar).Value = livreinfo.IDCat;
                        cmd.Parameters.Add("@description", SqlDbType.NVarChar).Value = livreinfo.Description;
                        cmd.Parameters.Add("@anneedit", SqlDbType.NVarChar).Value = livreinfo.DateRealisation;
                        cmd.ExecuteNonQuery();
                    }
                    SuccessMessage = "livre ajout� avec succ�s";
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception " + ex.ToString());
            }

            RedirectToPage("/livreIndex");
        }

        private void HandleInvalidValue(string fieldName)
        {
            livreinfo.DateRealisation = 0;
            ErrorMessage = $"Invalid value for {fieldName}";
        }

        private void PopulateDropdowns()
        {
            string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // Query to get all Editeurs
                string sqlEditeurs = "SELECT IDEditeur, NomEditeur FROM Editeur";
                using (SqlCommand cmd = new SqlCommand(sqlEditeurs, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Editeur.Add(new EditInfo { IDEditeur = reader.GetInt32(0), NomEditeur = reader.GetString(1) });
                    }
                    reader.Close();
                }

                // Query to get all Auteurs
                string sqlAuteurs = "SELECT IDAuteur, NomAuteur FROM Auteur";
                using (SqlCommand cmd = new SqlCommand(sqlAuteurs, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Auteur.Add(new AuteurInfo { IDAuteur = reader.GetInt32(0), NomAuteur = reader.GetString(1) });
                    }
                    reader.Close();
                }

                // Query to get all Categories
                string sqlCategories = "SELECT IDCat, NomCat FROM Categorie";
                using (SqlCommand cmd = new SqlCommand(sqlCategories, con))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Categorie.Add(new CatInfo { IDCat = reader.GetInt32(0), NomCat = reader.GetString(1) });
                    }
                    reader.Close();
                }
            }
        }
    }
}