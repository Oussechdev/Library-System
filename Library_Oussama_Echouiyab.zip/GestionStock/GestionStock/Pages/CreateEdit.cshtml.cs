using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace GestionStock.Pages
{
    public class CreateEditModel : PageModel
    {
        public EditInfo edit = new EditInfo();
        public string ErrorMessage = "";
        public string SuccessMessage = "";

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            edit.NomEditeur = Request.Form["nomed"];
            edit.DescripEditeur = Request.Form["descriptioned"];
            edit.EmailEdit = Request.Form["emailed"];
            edit.telephoneEdi = Request.Form["telephoned"];
            edit.AddressEdit = Request.Form["addressed"];

            if (edit.NomEditeur.Length == 0 || edit.DescripEditeur.Length == 0 || edit.DescripEditeur.Length == 0 || edit.EmailEdit.Length == 0 || edit.telephoneEdi.Length == 0 || edit.AddressEdit.Length == 0)
            {
                ErrorMessage = "Tous les champs sont obligatoires";
                return Page();
            }

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "INSERT INTO Editeur (NomEditeur, DescripEditeur, EmailEdit, telephoneEdi, AddressEdit) VALUES (@nomed, @descriptioned, @emailed, @telephoned, @addressed)";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nomed", edit.NomEditeur);
                        cmd.Parameters.AddWithValue("@descriptioned", edit.DescripEditeur);
                        cmd.Parameters.AddWithValue("@emailed", edit.EmailEdit);
                        cmd.Parameters.AddWithValue("@telephoned", edit.telephoneEdi);
                        cmd.Parameters.AddWithValue("@addressed", edit.AddressEdit);
                        cmd.ExecuteNonQuery();
                    }
                    SuccessMessage = "Cat�gorie ajout�e avec succ�s";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
                ErrorMessage = "Une erreur s'est produite lors de l'ajout de la cat�gorie.";
                return Page();
            }

            return RedirectToPage("/Editeur");
        }
    }
}