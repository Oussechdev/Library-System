using GestionStock.Pages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using static GestionStock.Pages.CreateAModel;

namespace GestionStock.Pages
{
    public class EditAModel : PageModel
    {
        public AuteurInfo auteurInfo = new AuteurInfo();

        public void OnGet()
        {
            string id = Request.Query["id"]!;
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string sql = "SELECT * FROM Auteur WHERE IDAuteur=@id";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        SqlDataReader rd = cmd.ExecuteReader();
                        if (rd.Read())
                        {
                            auteurInfo.IDAuteur = rd.GetInt32(0);
                            auteurInfo.NomAuteur = rd.GetString(1);
                            auteurInfo.EmailAuteur = rd.GetString(2);
                            auteurInfo.telephoneAut = rd.GetString(3);
                            auteurInfo.AdresseAut = rd.GetString(4);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public IActionResult OnPost()
        {
            auteurInfo.IDAuteur = Convert.ToInt32(Request.Form["id"]);
            auteurInfo.NomAuteur = Request.Form["nomed1"];
            auteurInfo.EmailAuteur = Request.Form["emailed1"];
            auteurInfo.telephoneAut = Request.Form["telephoned1"];
            auteurInfo.AdresseAut = Request.Form["addressed1"];

            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string sql = "UPDATE Auteur SET NomAuteur = @nomed1, EmailAuteur = @emailed1, telephoneAut = @telephoned1, AdresseAut = @addressed1 WHERE IDAuteur = @id";

                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@nomed1", auteurInfo.NomAuteur);
                        cmd.Parameters.AddWithValue("@emailed1", auteurInfo.EmailAuteur);
                        cmd.Parameters.AddWithValue("@telephoned1", auteurInfo.telephoneAut);
                        cmd.Parameters.AddWithValue("@addressed1", auteurInfo.AdresseAut);
                        cmd.Parameters.AddWithValue("@id", auteurInfo.IDAuteur);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
            }
            return RedirectToPage("/CreateA");
        }
    }

}