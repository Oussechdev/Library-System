using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GestionStock.Pages
{
    public class DeleteLivreModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
