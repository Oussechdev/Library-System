using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System;

namespace GestionStock.Pages
{
    public class LivreIndexModel : PageModel
    {
        public List<LivreInfo> ListLivre { get; } = new List<LivreInfo>();
        public void OnGet()
        {
            try
            {
                string connectionString = "Data Source=.\\sqlexpress;Initial Catalog=GestionLivreC;Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string sql = "SELECT * FROM Livre";
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    LivreInfo livreinf = new LivreInfo();
                    livreinf.ID = rd.GetInt32(0);
                    livreinf.Titre = rd.GetString(1);
                    livreinf.ISBN = rd.GetString(2);
                    livreinf.IDEditeur = rd.GetInt32(3);
                    livreinf.IDAuteur = rd.GetInt32(4);
                    livreinf.IDCat = rd.GetInt32(5);
                    livreinf.Description = rd.GetString(6);
                    livreinf.DateRealisation = rd.GetInt32(7);
                    ListLivre.Add(livreinf);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("Exception " + ex.ToString());
            }
        }
    }
    public class LivreInfo
    {
        public int ID { get; set; }
        public string? Titre { get; set; }
        public string? ISBN { get; set; }
        public int? IDEditeur { get; set; }
        public int? IDAuteur { get; set; }
        public int? IDCat { get; set; }
        public string? Description { get; set; }
        public int? DateRealisation { get; set; }
    }
}